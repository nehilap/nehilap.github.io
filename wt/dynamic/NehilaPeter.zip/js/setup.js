const filteredTags = ['aniNeh'];

const databaseUrl = "https://parseapi.back4app.com/classes/opinions";

const back4AppHeaders = {
	"X-Parse-Application-Id": "Tvs5yreyzTAKVdSumV0RbETbaTbjxf2pSAPgjgD2",
	"X-Parse-REST-API-Key": "T9ghaIz8pmyjcD6RBd0vZA5BJXxNBKHuHgYYjI2z"
}